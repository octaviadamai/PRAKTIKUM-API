package com.example.toko_kita

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
